package com.rana.phone

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.rgb(12, 20, 38))
        }

        val title = TextView(this).apply {
            text = "🛡️ Phone Guard Pro"
            textSize = 27f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        layout.addView(title)

        val subtitle = TextView(this).apply {
            text = "Your Phone Protection Center"
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        layout.addView(subtitle)

        val features = listOf(
            "🛡️ Security Scan",
            "🧹 Phone Cleaner",
            "🔒 App Lock",
            "🔐 Privacy Center"
        )

        features.forEach { feature ->
            val button = Button(this).apply {
                text = feature
                textSize = 18f
                setOnClickListener {
                    Toast.makeText(
                        this@MainActivity,
                        "$feature - Coming Soon",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
            layout.addView(button)
        }

        setContentView(layout)
    }
}
